# Assignment-4
SOC LAB-4
Creating SOAP web service using Axis 2 Implementation
